import { useState } from "react"
import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Check } from "lucide-react"

interface Course {
  id: string
  title: string
  description: string
  price: number | "Free"
  features: string[]
}

const courses: Course[] = [
  {
    id: "content-basics",
    title: "Content Creation Basics",
    description: "Learn the fundamentals of AI-assisted content creation",
    price: "Free",
    features: ["5 video lessons", "Basic prompt templates", "Community forum access"],
  },
  {
    id: "advanced-prompts",
    title: "Advanced Prompt Engineering",
    description: "Master the art of crafting effective prompts for AI",
    price: 49,
    features: ["10 video lessons", "Advanced prompt templates", "Live Q&A sessions", "Certificate of completion"],
  },
  {
    id: "content-strategy",
    title: "AI-Powered Content Strategy",
    description: "Develop a comprehensive content strategy using AI tools",
    price: 99,
    features: [
      "15 video lessons",
      "Strategy planning templates",
      "1-on-1 coaching session",
      "Lifetime access to course updates",
    ],
  },
]

interface CourseSelectionProps {
  onSelectCourse: (courseId: string) => void
}

export function CourseSelection({ onSelectCourse }: CourseSelectionProps) {
  const [selectedCourse, setSelectedCourse] = useState<string | null>(null)

  const handleSelectCourse = (courseId: string) => {
    setSelectedCourse(courseId)
    onSelectCourse(courseId)
  }

  return (
    <div className="grid gap-6 md:grid-cols-3">
      {courses.map((course) => (
        <motion.div
          key={course.id}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
        >
          <Card className={`h-full flex flex-col ${selectedCourse === course.id ? "ring-2 ring-blue-500" : ""}`}>
            <CardHeader>
              <CardTitle>{course.title}</CardTitle>
              <CardDescription>{course.description}</CardDescription>
            </CardHeader>
            <CardContent className="flex-grow">
              <ul className="space-y-2">
                {course.features.map((feature, index) => (
                  <li key={index} className="flex items-center">
                    <Check className="w-5 h-5 mr-2 text-green-500" />
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>
            </CardContent>
            <CardFooter className="flex justify-between items-center">
              <Badge variant={course.price === "Free" ? "secondary" : "default"}>
                {course.price === "Free" ? "Free" : `$${course.price}`}
              </Badge>
              <Button onClick={() => handleSelectCourse(course.id)}>
                {selectedCourse === course.id ? "Selected" : "Select"}
              </Button>
            </CardFooter>
          </Card>
        </motion.div>
      ))}
    </div>
  )
}

