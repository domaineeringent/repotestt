"use client"

import { useState, useEffect } from "react"
import { Link } from "lucide-react"

interface TocItem {
  id: string
  text: string
  level: number
}

export function TableOfContents() {
  const [toc, setToc] = useState<TocItem[]>([])

  useEffect(() => {
    const headings = Array.from(document.querySelectorAll("h2, h3, h4"))
    const tocItems = headings.map((heading) => ({
      id: heading.id,
      text: heading.textContent || "",
      level: Number.parseInt(heading.tagName.charAt(1)),
    }))
    setToc(tocItems)
  }, [])

  return (
    <nav className="space-y-2 text-sm">
      <h4 className="font-semibold mb-3 flex items-center">
        <Link className="w-4 h-4 mr-2" />
        Table of Contents
      </h4>
      {toc.map((item) => (
        <a
          key={item.id}
          href={`#${item.id}`}
          className={`block text-gray-600 dark:text-gray-300 hover:text-blue-600 dark:hover:text-blue-400 transition-colors ${
            item.level === 2 ? "pl-0" : item.level === 3 ? "pl-4" : "pl-8"
          }`}
        >
          {item.text}
        </a>
      ))}
    </nav>
  )
}

