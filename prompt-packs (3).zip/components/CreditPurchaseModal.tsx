"use client"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { toast } from "@/components/ui/use-toast"

interface CreditPurchaseModalProps {
  isOpen: boolean
  onClose: () => void
  onPurchase: (amount: number) => void
}

export function CreditPurchaseModal({ isOpen, onClose, onPurchase }: CreditPurchaseModalProps) {
  const [creditAmount, setCreditAmount] = useState(100)
  const [isProcessing, setIsProcessing] = useState(false)

  const handlePurchase = async () => {
    setIsProcessing(true)
    try {
      // Simulating a purchase process
      await new Promise((resolve) => setTimeout(resolve, 2000))
      onPurchase(creditAmount)
      toast({
        title: "Purchase Successful",
        description: `You've successfully purchased ${creditAmount} credits!`,
      })
      onClose()
    } catch (error) {
      toast({
        title: "Purchase Failed",
        description: "There was an error processing your purchase. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsProcessing(false)
    }
  }

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50"
        >
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.9, opacity: 0 }}
            className="bg-gray-900 p-6 rounded-lg w-full max-w-md"
          >
            <Card>
              <CardHeader>
                <CardTitle className="text-2xl font-bold">Purchase Credits</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="creditAmount">Number of Credits</Label>
                    <Input
                      id="creditAmount"
                      type="number"
                      value={creditAmount}
                      onChange={(e) => setCreditAmount(Number.parseInt(e.target.value))}
                      min={1}
                    />
                  </div>
                  <div className="text-right">
                    <p className="text-lg font-semibold">Total: ${(creditAmount * 0.1).toFixed(2)}</p>
                    <p className="text-sm text-gray-400">$0.10 per credit</p>
                  </div>
                </div>
              </CardContent>
              <CardFooter className="flex justify-end space-x-2">
                <Button variant="outline" onClick={onClose} disabled={isProcessing}>
                  Cancel
                </Button>
                <Button onClick={handlePurchase} disabled={isProcessing}>
                  {isProcessing ? "Processing..." : "Purchase Credits"}
                </Button>
              </CardFooter>
            </Card>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}

