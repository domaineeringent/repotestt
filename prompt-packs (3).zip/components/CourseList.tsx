import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { Edit, Trash } from "lucide-react"

const courses = [
  { id: 1, title: "Content Creation Basics", students: 523, revenue: 0, status: "Published" },
  { id: 2, title: "Advanced Prompt Engineering", students: 342, revenue: 16758, status: "Published" },
  { id: 3, title: "AI-Powered Content Strategy", students: 189, revenue: 18711, status: "Published" },
  { id: 4, title: "Mastering SEO with AI", students: 0, revenue: 0, status: "Draft" },
]

export function CourseList() {
  return (
    <Table>
      <TableHeader>
        <TableRow>
          <TableHead>Title</TableHead>
          <TableHead>Students</TableHead>
          <TableHead>Revenue</TableHead>
          <TableHead>Status</TableHead>
          <TableHead>Actions</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {courses.map((course) => (
          <TableRow key={course.id}>
            <TableCell className="font-medium">{course.title}</TableCell>
            <TableCell>{course.students}</TableCell>
            <TableCell>${course.revenue.toLocaleString()}</TableCell>
            <TableCell>{course.status}</TableCell>
            <TableCell>
              <Button variant="ghost" size="sm" className="mr-2">
                <Edit className="h-4 w-4" />
              </Button>
              <Button variant="ghost" size="sm">
                <Trash className="h-4 w-4" />
              </Button>
            </TableCell>
          </TableRow>
        ))}
      </TableBody>
    </Table>
  )
}

