import Link from "next/link"
import Image from "next/image"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

interface BlogCardProps {
  title: string
  excerpt: string
  date: string
  author: string
  slug: string
  category: string
  imageUrl: string
}

export function BlogCard({ title, excerpt, date, author, slug, category, imageUrl }: BlogCardProps) {
  return (
    <Card className="overflow-hidden transition-shadow hover:shadow-lg">
      <Link href={`/blog/${slug}`}>
        <div className="relative h-48 w-full">
          <Image src={imageUrl || "/placeholder.svg"} alt={title} layout="fill" objectFit="cover" />
        </div>
        <CardContent className="p-4">
          <Badge className="mb-2">{category}</Badge>
          <h3 className="text-xl font-semibold mb-2">{title}</h3>
          <p className="text-gray-600 dark:text-gray-300 mb-4">{excerpt}</p>
        </CardContent>
        <CardFooter className="px-4 py-3 bg-gray-50 dark:bg-gray-800 text-sm text-gray-500 dark:text-gray-400">
          <span>{author}</span>
          <span className="ml-auto">{date}</span>
        </CardFooter>
      </Link>
    </Card>
  )
}

