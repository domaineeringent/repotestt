import Image from "next/image"
import { Badge } from "@/components/ui/badge"

interface ArticleHeaderProps {
  title: string
  date: string
  author: string
  category: string
  imageUrl: string
}

export function ArticleHeader({ title, date, author, category, imageUrl }: ArticleHeaderProps) {
  return (
    <header className="mb-8">
      <div className="relative h-64 md:h-96 w-full mb-6">
        <Image
          src={imageUrl || "/placeholder.svg"}
          alt={title}
          layout="fill"
          objectFit="cover"
          className="rounded-lg"
        />
      </div>
      <Badge className="mb-4">{category}</Badge>
      <h1 className="text-3xl md:text-4xl font-bold mb-4">{title}</h1>
      <div className="flex items-center text-gray-600 dark:text-gray-300">
        <span>{author}</span>
        <span className="mx-2">•</span>
        <time dateTime={date}>{date}</time>
      </div>
    </header>
  )
}

