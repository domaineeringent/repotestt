import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { Mail } from "lucide-react"

const students = [
  { id: 1, name: "Alice Johnson", email: "alice@example.com", coursesEnrolled: 2, lastActive: "2023-06-15" },
  { id: 2, name: "Bob Smith", email: "bob@example.com", coursesEnrolled: 1, lastActive: "2023-06-14" },
  { id: 3, name: "Charlie Brown", email: "charlie@example.com", coursesEnrolled: 3, lastActive: "2023-06-16" },
  { id: 4, name: "Diana Ross", email: "diana@example.com", coursesEnrolled: 2, lastActive: "2023-06-13" },
]

export function StudentList() {
  return (
    <Table>
      <TableHeader>
        <TableRow>
          <TableHead>Name</TableHead>
          <TableHead>Email</TableHead>
          <TableHead>Courses Enrolled</TableHead>
          <TableHead>Last Active</TableHead>
          <TableHead>Actions</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {students.map((student) => (
          <TableRow key={student.id}>
            <TableCell className="font-medium">{student.name}</TableCell>
            <TableCell>{student.email}</TableCell>
            <TableCell>{student.coursesEnrolled}</TableCell>
            <TableCell>{student.lastActive}</TableCell>
            <TableCell>
              <Button variant="ghost" size="sm">
                <Mail className="h-4 w-4 mr-2" />
                Contact
              </Button>
            </TableCell>
          </TableRow>
        ))}
      </TableBody>
    </Table>
  )
}

