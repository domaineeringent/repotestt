"use client"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { useRouter } from "next/navigation"
import type React from "react"
import { CourseSelection } from "@/components/CourseSelection"

const steps = [
  {
    question: "What's your primary content creation challenge?",
    options: ["Lack of ideas", "Time constraints", "Maintaining quality", "Scaling content production"],
  },
  {
    question: "How often do you create content?",
    options: ["Daily", "Weekly", "Monthly", "Occasionally"],
  },
  {
    question: "What type of content do you primarily create?",
    options: ["Blog posts", "Social media posts", "Marketing copy", "Product descriptions"],
  },
]

export function ConversionFunnel() {
  const [currentStep, setCurrentStep] = useState(0)
  const [answers, setAnswers] = useState<string[]>([])
  const [email, setEmail] = useState("")
  const [selectedCourse, setSelectedCourse] = useState<string | null>(null)
  const router = useRouter()

  const handleAnswer = (answer: string) => {
    const newAnswers = [...answers, answer]
    setAnswers(newAnswers)

    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1)
    } else {
      setCurrentStep(steps.length)
    }
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    router.push(`/free-trial?email=${encodeURIComponent(email)}&course=${encodeURIComponent(selectedCourse || "")}`)
  }

  return (
    <div className="max-w-md mx-auto bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6">
      <AnimatePresence mode="wait">
        {currentStep < steps.length ? (
          <motion.div
            key={currentStep}
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -50 }}
            transition={{ duration: 0.3 }}
          >
            <h2 className="text-2xl font-bold mb-4">{steps[currentStep].question}</h2>
            <RadioGroup onValueChange={handleAnswer} className="space-y-2">
              {steps[currentStep].options.map((option) => (
                <div key={option} className="flex items-center space-x-2">
                  <RadioGroupItem value={option} id={option} />
                  <Label htmlFor={option}>{option}</Label>
                </div>
              ))}
            </RadioGroup>
          </motion.div>
        ) : (
          <motion.form
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.3 }}
            onSubmit={handleSubmit}
            className="space-y-4"
          >
            <h2 className="text-2xl font-bold mb-4">Start Your Free 7-Day Trial</h2>
            <div>
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                placeholder="you@example.com"
              />
            </div>
            <CourseSelection onSelectCourse={setSelectedCourse} />
            <Button type="submit" className="w-full" disabled={!selectedCourse}>
              Continue to Free Trial
            </Button>
            <p className="text-sm text-center text-gray-500">
              {selectedCourse === "content-basics"
                ? "Start your free course now. No payment required."
                : "You'll need to enter payment details to start your free trial. No charges for 7 days."}
            </p>
          </motion.form>
        )}
      </AnimatePresence>
    </div>
  )
}

