import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export function SiteSettings() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Site Settings</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center justify-between">
          <Label htmlFor="maintenance-mode">Maintenance Mode</Label>
          <Switch id="maintenance-mode" />
        </div>
        <div className="flex items-center justify-between">
          <Label htmlFor="user-registration">Allow User Registration</Label>
          <Switch id="user-registration" />
        </div>
        <div className="space-y-2">
          <Label htmlFor="site-name">Site Name</Label>
          <Input id="site-name" placeholder="PromptPacks" />
        </div>
        <div className="space-y-2">
          <Label htmlFor="site-description">Site Description</Label>
          <Input id="site-description" placeholder="AI-powered content creation platform" />
        </div>
        <Button>Save Settings</Button>
      </CardContent>
    </Card>
  )
}

