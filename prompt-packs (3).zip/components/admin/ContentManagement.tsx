import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { useState } from "react"

const initialContent = [
  { id: 1, title: "Getting Started with PromptPacks", type: "Blog Post", author: "John Doe", status: "Published" },
  { id: 2, title: "Advanced Prompt Engineering", type: "Course", author: "Jane Smith", status: "Draft" },
  { id: 3, title: "AI Content Creation Tips", type: "Newsletter", author: "Bob Johnson", status: "Scheduled" },
]

export function ContentManagement() {
  const [content, setContent] = useState(initialContent)
  const [searchTerm, setSearchTerm] = useState("")

  const filteredContent = content.filter(
    (item) =>
      item.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.type.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.author.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  return (
    <div className="space-y-4">
      <Input placeholder="Search content..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} />
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Title</TableHead>
            <TableHead>Type</TableHead>
            <TableHead>Author</TableHead>
            <TableHead>Status</TableHead>
            <TableHead>Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {filteredContent.map((item) => (
            <TableRow key={item.id}>
              <TableCell>{item.title}</TableCell>
              <TableCell>{item.type}</TableCell>
              <TableCell>{item.author}</TableCell>
              <TableCell>{item.status}</TableCell>
              <TableCell>
                <Button variant="outline" size="sm" className="mr-2">
                  Edit
                </Button>
                <Button variant="destructive" size="sm">
                  Delete
                </Button>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  )
}

