import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Bar, BarChart, Line, LineChart, ResponsiveContainer, XAxis, YAxis } from "recharts"

const userActivityData = [
  { name: "Mon", users: 120 },
  { name: "Tue", users: 150 },
  { name: "Wed", users: 180 },
  { name: "Thu", users: 200 },
  { name: "Fri", users: 220 },
  { name: "Sat", users: 190 },
  { name: "Sun", users: 140 },
]

const contentCreationData = [
  { name: "Week 1", content: 50 },
  { name: "Week 2", content: 80 },
  { name: "Week 3", content: 100 },
  { name: "Week 4", content: 120 },
]

export function AnalyticsDashboard() {
  return (
    <div className="grid gap-4 md:grid-cols-2">
      <Card>
        <CardHeader>
          <CardTitle>User Activity</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={userActivityData}>
              <XAxis dataKey="name" />
              <YAxis />
              <Bar dataKey="users" fill="#8884d8" />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>
      <Card>
        <CardHeader>
          <CardTitle>Content Creation Trend</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={contentCreationData}>
              <XAxis dataKey="name" />
              <YAxis />
              <Line type="monotone" dataKey="content" stroke="#82ca9d" />
            </LineChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>
    </div>
  )
}

