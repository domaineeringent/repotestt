"use client"

import { useEffect, useRef } from "react"
import { motion } from "framer-motion"
import * as THREE from "three"
import { createIMAXScene } from "@/utils/3dAnimations"
import { Button } from "@/components/ui/button"

const plans = [
  {
    name: "Starter",
    price: 49,
    credits: 100,
    features: ["Basic content types", "Email support", "24/7 AI assistance"],
  },
  {
    name: "Pro",
    price: 99,
    credits: 300,
    features: ["All content types", "Priority support", "Advanced customization", "API access"],
  },
  {
    name: "Enterprise",
    price: "Custom",
    credits: "Unlimited",
    features: ["Custom content types", "Dedicated account manager", "Onboarding & training", "Custom integrations"],
  },
]

export function IMAXPricing() {
  const containerRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (containerRef.current) {
      const { scene, camera, renderer, composer } = createIMAXScene(containerRef.current)

      // Add holographic price displays
      plans.forEach((_, index) => {
        const geometry = new THREE.CircleGeometry(0.5, 32)
        const material = new THREE.MeshPhongMaterial({
          color: 0x4a90e2,
          transparent: true,
          opacity: 0.7,
          side: THREE.DoubleSide,
        })
        const circle = new THREE.Mesh(geometry, material)
        circle.position.set((index - 1) * 2, 0, 0)
        scene.add(circle)
      })

      const animate = () => {
        requestAnimationFrame(animate)
        scene.rotation.y += 0.001
        composer.render()
      }

      animate()

      const handleResize = () => {
        camera.aspect = containerRef.current!.clientWidth / containerRef.current!.clientHeight
        camera.updateProjectionMatrix()
        renderer.setSize(containerRef.current!.clientWidth, containerRef.current!.clientHeight)
        composer.setSize(containerRef.current!.clientWidth, containerRef.current!.clientHeight)
      }

      window.addEventListener("resize", handleResize)

      return () => {
        window.removeEventListener("resize", handleResize)
        containerRef.current?.removeChild(renderer.domElement)
      }
    }
  }, [])

  return (
    <div className="relative min-h-screen bg-gray-900 overflow-hidden">
      <div ref={containerRef} className="absolute inset-0" />
      <div className="relative z-10 container mx-auto px-4 py-16">
        <motion.h2
          className="text-4xl md:text-5xl font-bold mb-12 text-center text-white"
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1 }}
        >
          Choose Your Plan
        </motion.h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {plans.map((plan, index) => (
            <motion.div
              key={index}
              className="bg-gray-800 bg-opacity-50 backdrop-filter backdrop-blur-lg rounded-lg p-6 flex flex-col"
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 1, delay: index * 0.2 }}
            >
              <h3 className="text-2xl font-semibold mb-4 text-blue-400">{plan.name}</h3>
              <div className="text-4xl font-bold mb-4 text-white">
                ${plan.price}
                <span className="text-xl font-normal">/month</span>
              </div>
              <div className="text-gray-300 mb-4">{plan.credits} credits</div>
              <ul className="text-gray-300 mb-8 flex-grow">
                {plan.features.map((feature, featureIndex) => (
                  <li key={featureIndex} className="mb-2">
                    ✓ {feature}
                  </li>
                ))}
              </ul>
              <Button className="w-full bg-blue-600 hover:bg-blue-700">Choose {plan.name}</Button>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  )
}

