"use client"

import { useEffect, useRef } from "react"
import { motion } from "framer-motion"
import * as THREE from "three"
import { createIMAXScene } from "@/utils/3dAnimations"

const features = [
  {
    title: "AI-Powered Content Generation",
    description: "Harness the power of advanced AI to create diverse content packs",
  },
  { title: "Customizable Outputs", description: "Tailor your content to match your brand voice and style" },
  { title: "Rapid Turnaround", description: "Get high-quality content in minutes, not days" },
  { title: "Multi-Format Support", description: "Generate content for various platforms and mediums" },
]

export function IMAXFeatures() {
  const containerRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (containerRef.current) {
      const { scene, camera, renderer, composer } = createIMAXScene(containerRef.current)

      // Add floating orbs
      features.forEach((_, index) => {
        const geometry = new THREE.SphereGeometry(0.2, 32, 32)
        const material = new THREE.MeshPhongMaterial({ color: 0x4a90e2 })
        const sphere = new THREE.Mesh(geometry, material)
        sphere.position.set(
          Math.cos((index / features.length) * Math.PI * 2) * 2,
          Math.sin((index / features.length) * Math.PI * 2) * 2,
          0,
        )
        scene.add(sphere)
      })

      const animate = () => {
        requestAnimationFrame(animate)
        scene.rotation.y += 0.001
        composer.render()
      }

      animate()

      const handleResize = () => {
        camera.aspect = containerRef.current!.clientWidth / containerRef.current!.clientHeight
        camera.updateProjectionMatrix()
        renderer.setSize(containerRef.current!.clientWidth, containerRef.current!.clientHeight)
        composer.setSize(containerRef.current!.clientWidth, containerRef.current!.clientHeight)
      }

      window.addEventListener("resize", handleResize)

      return () => {
        window.removeEventListener("resize", handleResize)
        containerRef.current?.removeChild(renderer.domElement)
      }
    }
  }, [])

  return (
    <div className="relative min-h-screen bg-gray-900 overflow-hidden">
      <div ref={containerRef} className="absolute inset-0" />
      <div className="relative z-10 container mx-auto px-4 py-16">
        <motion.h2
          className="text-4xl md:text-5xl font-bold mb-12 text-center text-white"
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1 }}
        >
          Revolutionize Your Content Creation
        </motion.h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {features.map((feature, index) => (
            <motion.div
              key={index}
              className="bg-gray-800 bg-opacity-50 backdrop-filter backdrop-blur-lg rounded-lg p-6"
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 1, delay: index * 0.2 }}
            >
              <h3 className="text-2xl font-semibold mb-4 text-blue-400">{feature.title}</h3>
              <p className="text-gray-300">{feature.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  )
}

