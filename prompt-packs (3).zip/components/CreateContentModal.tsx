import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"

interface CreateContentModalProps {
  isOpen: boolean
  onClose: () => void
}

export function CreateContentModal({ isOpen, onClose }: CreateContentModalProps) {
  const [contentType, setContentType] = useState("")
  const [prompt, setPrompt] = useState("")
  const [tone, setTone] = useState("")
  const [targetAudience, setTargetAudience] = useState("")
  const [wordCount, setWordCount] = useState([500])
  const [additionalInstructions, setAdditionalInstructions] = useState("")

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Here you would typically send the data to your backend
    console.log({ contentType, prompt, tone, targetAudience, wordCount: wordCount[0], additionalInstructions })
    onClose()
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[600px]">
        <DialogHeader>
          <DialogTitle>Create New Content</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="contentType">Content Type</Label>
            <Select onValueChange={setContentType} required>
              <SelectTrigger>
                <SelectValue placeholder="Select content type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="blogPost">Blog Post</SelectItem>
                <SelectItem value="socialMedia">Social Media Post</SelectItem>
                <SelectItem value="emailNewsletter">Email Newsletter</SelectItem>
                <SelectItem value="productDescription">Product Description</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label htmlFor="prompt">Prompt</Label>
            <Textarea
              id="prompt"
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="Enter your content prompt"
              required
            />
          </div>
          <div>
            <Label htmlFor="tone">Tone</Label>
            <Select onValueChange={setTone} required>
              <SelectTrigger>
                <SelectValue placeholder="Select tone" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="professional">Professional</SelectItem>
                <SelectItem value="casual">Casual</SelectItem>
                <SelectItem value="humorous">Humorous</SelectItem>
                <SelectItem value="formal">Formal</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label htmlFor="targetAudience">Target Audience</Label>
            <Input
              id="targetAudience"
              value={targetAudience}
              onChange={(e) => setTargetAudience(e.target.value)}
              placeholder="Describe your target audience"
              required
            />
          </div>
          <div>
            <Label htmlFor="wordCount">Word Count</Label>
            <Slider id="wordCount" min={100} max={2000} step={100} value={wordCount} onValueChange={setWordCount} />
            <div className="text-center mt-2">{wordCount} words</div>
          </div>
          <div>
            <Label htmlFor="additionalInstructions">Additional Instructions</Label>
            <Textarea
              id="additionalInstructions"
              value={additionalInstructions}
              onChange={(e) => setAdditionalInstructions(e.target.value)}
              placeholder="Any additional instructions or requirements"
            />
          </div>
          <DialogFooter>
            <Button type="submit">Create Content (5 Credits)</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}

