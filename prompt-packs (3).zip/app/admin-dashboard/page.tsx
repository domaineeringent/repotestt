"use client"
import { UltraConvertingMenu } from "@/components/UltraConvertingMenu"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Settings, Users, BarChart, FileText, Palette } from "lucide-react"
import { SiteSettings } from "@/components/admin/SiteSettings"
import { UserManagement } from "@/components/admin/UserManagement"
import { ContentManagement } from "@/components/admin/ContentManagement"
import { AnalyticsDashboard } from "@/components/admin/AnalyticsDashboard"
import { BrandSettings } from "@/components/admin/BrandSettings"

export default function AdminDashboard() {
  return (
    <div className="min-h-screen bg-gray-100 dark:bg-gray-900">
      <UltraConvertingMenu />
      <main className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-8">Admin Dashboard</h1>

        <Tabs defaultValue="site-settings" className="space-y-4">
          <TabsList>
            <TabsTrigger value="site-settings">
              <Settings className="mr-2 h-4 w-4" />
              Site Settings
            </TabsTrigger>
            <TabsTrigger value="user-management">
              <Users className="mr-2 h-4 w-4" />
              User Management
            </TabsTrigger>
            <TabsTrigger value="content-management">
              <FileText className="mr-2 h-4 w-4" />
              Content Management
            </TabsTrigger>
            <TabsTrigger value="analytics">
              <BarChart className="mr-2 h-4 w-4" />
              Analytics
            </TabsTrigger>
            <TabsTrigger value="brand-settings">
              <Palette className="mr-2 h-4 w-4" />
              Brand Settings
            </TabsTrigger>
          </TabsList>
          <TabsContent value="site-settings">
            <SiteSettings />
          </TabsContent>
          <TabsContent value="user-management">
            <UserManagement />
          </TabsContent>
          <TabsContent value="content-management">
            <ContentManagement />
          </TabsContent>
          <TabsContent value="analytics">
            <AnalyticsDashboard />
          </TabsContent>
          <TabsContent value="brand-settings">
            <BrandSettings />
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}

