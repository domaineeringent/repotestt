import { UltraConvertingMenu } from "@/components/UltraConvertingMenu"
import { BlogCard } from "@/components/BlogCard"

const blogPosts = [
  {
    title: "Maximizing Productivity with AI-Generated Content",
    excerpt: "Learn how to leverage PromptPacks to streamline your content creation process and boost productivity.",
    date: "June 20, 2025",
    author: "Alice Johnson",
    slug: "maximizing-productivity-with-ai-generated-content",
    category: "Productivity",
    imageUrl: "/placeholder.svg?height=400&width=600",
  },
  {
    title: "The Future of Content Creation: AI and Human Collaboration",
    excerpt: "Explore the synergy between artificial intelligence and human creativity in modern content production.",
    date: "June 18, 2025",
    author: "Bob Smith",
    slug: "future-of-content-creation-ai-and-human-collaboration",
    category: "AI Trends",
    imageUrl: "/placeholder.svg?height=400&width=600",
  },
  {
    title: "SEO Optimization Techniques for AI-Generated Content",
    excerpt: "Discover effective strategies to ensure your AI-created content ranks well in search engines.",
    date: "June 15, 2025",
    author: "Charlie Brown",
    slug: "seo-optimization-techniques-for-ai-generated-content",
    category: "SEO",
    imageUrl: "/placeholder.svg?height=400&width=600",
  },
]

export default function BlogIndex() {
  return (
    <div className="min-h-screen bg-gray-100 dark:bg-gray-900">
      <UltraConvertingMenu />
      <main className="container mx-auto px-4 py-12">
        <h1 className="text-4xl font-bold mb-8 text-center">PromptPacks Blog</h1>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {blogPosts.map((post) => (
            <BlogCard key={post.slug} {...post} />
          ))}
        </div>
      </main>
    </div>
  )
}

