"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { UltraConvertingMenu } from "@/components/UltraConvertingMenu"
import { CreditPurchaseModal } from "@/components/CreditPurchaseModal"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { toast } from "@/components/ui/use-toast"
import { Loader2, Zap, Package, Download } from "lucide-react"

export default function Dashboard() {
  const [credits, setCredits] = useState(100)
  const [prompt, setPrompt] = useState("")
  const [isGenerating, setIsGenerating] = useState(false)
  const [generatedContent, setGeneratedContent] = useState<string | null>(null)
  const [isPurchaseModalOpen, setIsPurchaseModalOpen] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (credits > 0 && prompt.trim() !== "") {
      setIsGenerating(true)
      setGeneratedContent(null)

      try {
        // Simulating content generation
        await new Promise((resolve) => setTimeout(resolve, 3000))

        const mockContent =
          `Here's your generated content based on the prompt: "${prompt}"\n\n` +
          `1. Blog Post Title: "10 Ways to Boost Your Productivity"\n` +
          `2. Social Media Post: "Struggling with productivity? Check out our latest blog post for game-changing tips! #ProductivityHacks"\n` +
          `3. Email Subject Line: "Unlock Your Productivity Potential with These Expert Tips"\n\n` +
          `... (more content would be generated here)`

        setGeneratedContent(mockContent)
        setCredits(credits - 1)
        toast({
          title: "Content Generated Successfully",
          description: "Your content pack is ready for review and download.",
        })
      } catch (error) {
        toast({
          title: "Generation Failed",
          description: "There was an error generating your content. Please try again.",
          variant: "destructive",
        })
      } finally {
        setIsGenerating(false)
      }
    }
  }

  const handlePurchaseCredits = (amount: number) => {
    setCredits(credits + amount)
  }

  return (
    <div className="min-h-screen bg-gray-900 text-white">
      <UltraConvertingMenu />
      <main className="container mx-auto px-4 py-8">
        <motion.h1
          className="text-4xl font-bold mb-8"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          Welcome to Your PromptPacks Dashboard
        </motion.h1>

        <div className="grid md:grid-cols-3 gap-8">
          <Card className="col-span-2">
            <CardHeader>
              <CardTitle>Generate Content</CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-4">
                <Textarea
                  placeholder="Enter your prompt here..."
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                  rows={4}
                  className="w-full"
                />
                <div className="flex justify-between items-center">
                  <span>Credits: {credits}</span>
                  <Button type="submit" disabled={isGenerating || credits === 0}>
                    {isGenerating ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Generating...
                      </>
                    ) : (
                      <>
                        <Zap className="mr-2 h-4 w-4" />
                        Generate Pack (1 Credit)
                      </>
                    )}
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Quick Stats</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <p className="text-sm text-gray-400">Total Packs Generated</p>
                  <p className="text-2xl font-bold">24</p>
                </div>
                <div>
                  <p className="text-sm text-gray-400">Remaining Credits</p>
                  <p className="text-2xl font-bold">{credits}</p>
                </div>
                <Button className="w-full" onClick={() => setIsPurchaseModalOpen(true)}>
                  <Package className="mr-2 h-4 w-4" />
                  Buy More Credits
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        {generatedContent && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="mt-8"
          >
            <Card>
              <CardHeader>
                <CardTitle>Generated Content Pack</CardTitle>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="preview">
                  <TabsList>
                    <TabsTrigger value="preview">Preview</TabsTrigger>
                    <TabsTrigger value="raw">Raw Content</TabsTrigger>
                  </TabsList>
                  <TabsContent value="preview">
                    <div className="bg-gray-800 p-4 rounded-md">
                      <pre className="whitespace-pre-wrap">{generatedContent}</pre>
                    </div>
                  </TabsContent>
                  <TabsContent value="raw">
                    <Textarea value={generatedContent} readOnly className="w-full h-64" />
                  </TabsContent>
                </Tabs>
                <div className="mt-4 flex justify-end">
                  <Button>
                    <Download className="mr-2 h-4 w-4" />
                    Download Pack
                  </Button>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="mt-8"
        >
          <Card>
            <CardHeader>
              <CardTitle>Recent Packs</CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2">
                <li className="flex justify-between items-center">
                  <span>Social Media Campaign - June 15, 2025</span>
                  <Button variant="outline" size="sm">
                    View
                  </Button>
                </li>
                <li className="flex justify-between items-center">
                  <span>Blog Post Ideas - June 10, 2025</span>
                  <Button variant="outline" size="sm">
                    View
                  </Button>
                </li>
                <li className="flex justify-between items-center">
                  <span>Email Newsletter - June 5, 2025</span>
                  <Button variant="outline" size="sm">
                    View
                  </Button>
                </li>
              </ul>
            </CardContent>
          </Card>
        </motion.div>
      </main>

      <CreditPurchaseModal
        isOpen={isPurchaseModalOpen}
        onClose={() => setIsPurchaseModalOpen(false)}
        onPurchase={handlePurchaseCredits}
      />
    </div>
  )
}

