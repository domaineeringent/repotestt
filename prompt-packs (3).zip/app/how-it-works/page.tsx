import { UltraConvertingMenu } from "@/components/UltraConvertingMenu"
import { Button } from "@/components/ui/button"
import { motion } from "framer-motion"
import { ArrowRight, Zap, Edit, Package } from "lucide-react"

export default function HowItWorks() {
  return (
    <main className="bg-gray-900 text-white">
      <UltraConvertingMenu />

      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-b from-purple-900 to-gray-900">
        <div className="container mx-auto px-4">
          <motion.h1
            className="text-5xl md:text-6xl font-bold mb-8 text-center"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            How PromptPacks Works
          </motion.h1>
          <motion.p
            className="text-xl mb-12 text-center max-w-3xl mx-auto"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            Discover how our AI-powered platform transforms your ideas into high-quality content in just a few simple
            steps.
          </motion.p>
        </div>
      </section>

      {/* Step-by-Step Process */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl font-bold mb-12 text-center">Our Simple 3-Step Process</h2>
          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                icon: Zap,
                title: "Input Your Prompt",
                description: "Craft a simple prompt describing the content you need.",
              },
              {
                icon: Edit,
                title: "AI Magic Happens",
                description: "Our advanced AI processes your prompt and generates diverse content.",
              },
              {
                icon: Package,
                title: "Receive Your Pack",
                description: "Get a comprehensive pack of high-quality, relevant content.",
              },
            ].map((step, index) => (
              <motion.div
                key={index}
                className="bg-gray-800 p-6 rounded-lg text-center"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.2 }}
              >
                <step.icon className="w-16 h-16 mx-auto mb-4 text-blue-400" />
                <h3 className="text-2xl font-semibold mb-4">{step.title}</h3>
                <p>{step.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Detailed Explanation */}
      <section className="py-20 bg-gray-800">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl font-bold mb-12 text-center">Diving Deeper into the Process</h2>
          <div className="space-y-12">
            <div className="grid md:grid-cols-2 gap-8 items-center">
              <div>
                <h3 className="text-2xl font-semibold mb-4">1. Crafting Your Prompt</h3>
                <p className="text-lg mb-4">
                  Start by describing the content you need. Whether it's a blog post, social media campaign, or product
                  description, our AI understands context and intent.
                </p>
                <p className="text-lg">
                  Pro tip: The more specific your prompt, the better the results. Include details about tone, style, and
                  target audience for optimal output.
                </p>
              </div>
              <div className="bg-gray-700 p-6 rounded-lg">
                <h4 className="text-xl font-semibold mb-4">Example Prompt:</h4>
                <p>
                  "Create a blog post about the benefits of meditation for stress relief. Target audience: busy
                  professionals. Tone: informative yet approachable. Include scientific facts and practical tips."
                </p>
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-8 items-center">
              <div className="order-2 md:order-1">
                <h4 className="text-xl font-semibold mb-4">What happens behind the scenes:</h4>
                <ul className="list-disc list-inside space-y-2">
                  <li>Natural Language Processing to understand the prompt</li>
                  <li>Context analysis to determine relevant information</li>
                  <li>Access to vast knowledge bases for accurate content</li>
                  <li>Application of writing styles and tones</li>
                </ul>
              </div>
              <div className="order-1 md:order-2">
                <h3 className="text-2xl font-semibold mb-4">2. AI Content Generation</h3>
                <p className="text-lg mb-4">
                  Our state-of-the-art AI model processes your prompt, tapping into its extensive knowledge base to
                  generate relevant, high-quality content.
                </p>
                <p className="text-lg">
                  The AI considers factors like context, tone, style, and target audience to create content that feels
                  personalized and on-brand.
                </p>
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-8 items-center">
              <div>
                <h3 className="text-2xl font-semibold mb-4">3. Delivering Your Content Pack</h3>
                <p className="text-lg mb-4">
                  Within minutes, you'll receive a comprehensive content pack tailored to your prompt. This pack
                  includes various content pieces, ensuring you have multiple options to choose from.
                </p>
                <p className="text-lg">
                  Each pack is designed to be diverse yet cohesive, giving you the flexibility to use the content as-is
                  or as a strong foundation for further customization.
                </p>
              </div>
              <div className="bg-gray-700 p-6 rounded-lg">
                <h4 className="text-xl font-semibold mb-4">Your Content Pack May Include:</h4>
                <ul className="list-disc list-inside space-y-2">
                  <li>Full-length blog post</li>
                  <li>Social media posts for various platforms</li>
                  <li>Email newsletter content</li>
                  <li>Key talking points or bullet lists</li>
                  <li>SEO-optimized meta descriptions</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Benefits */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl font-bold mb-12 text-center">Why Choose PromptPacks?</h2>
          <div className="grid md:grid-cols-2 gap-8">
            {[
              {
                title: "Time-Saving",
                description:
                  "Generate weeks' worth of content in minutes, freeing up your time for strategy and creativity.",
              },
              {
                title: "Cost-Effective",
                description: "Reduce content creation costs while maintaining high-quality output.",
              },
              {
                title: "Consistent Quality",
                description:
                  "Our AI ensures consistently high-quality content, eliminating writer's block and inconsistencies.",
              },
              {
                title: "Scalable Solution",
                description:
                  "Easily scale your content production to meet growing demands without hiring additional staff.",
              },
              {
                title: "Versatile Output",
                description: "From blog posts to social media content, get diverse content types from a single prompt.",
              },
              {
                title: "SEO-Friendly",
                description:
                  "Our AI is trained to create content that's optimized for search engines, helping improve your online visibility.",
              },
            ].map((benefit, index) => (
              <motion.div
                key={index}
                className="bg-gray-800 p-6 rounded-lg"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <h3 className="text-2xl font-semibold mb-4">{benefit.title}</h3>
                <p className="text-lg">{benefit.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-20 bg-blue-600">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-4xl md:text-5xl font-bold mb-8">Ready to Transform Your Content Creation?</h2>
          <p className="text-xl mb-8">
            Join thousands of satisfied customers and start creating amazing content today.
          </p>
          <Button size="lg" className="bg-white text-blue-600 hover:bg-gray-100">
            Start Your Free Trial <ArrowRight className="ml-2" />
          </Button>
        </div>
      </section>
    </main>
  )
}

