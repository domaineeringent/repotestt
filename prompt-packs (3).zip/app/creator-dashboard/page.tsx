"use client"

import { useState } from "react"
import { UltraConvertingMenu } from "@/components/UltraConvertingMenu"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { BarChart, Users, BookOpen, DollarSign, Plus, FileText } from "lucide-react"
import { CourseList } from "@/components/CourseList"
import { CourseAnalytics } from "@/components/CourseAnalytics"
import { StudentList } from "@/components/StudentList"
import { CreateCourseModal } from "@/components/CreateCourseModal"
import { CreateContentModal } from "@/components/CreateContentModal"

export default function CreatorDashboard() {
  const [isCreateCourseModalOpen, setIsCreateCourseModalOpen] = useState(false)
  const [isCreateContentModalOpen, setIsCreateContentModalOpen] = useState(false)

  return (
    <div className="min-h-screen bg-gray-100 dark:bg-gray-900">
      <UltraConvertingMenu />
      <main className="container mx-auto px-4 py-8">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-bold">Course Creator Dashboard</h1>
          <div>
            <Button onClick={() => setIsCreateContentModalOpen(true)} className="mr-4">
              <FileText className="mr-2 h-4 w-4" /> Create Content
            </Button>
            <Button onClick={() => setIsCreateCourseModalOpen(true)}>
              <Plus className="mr-2 h-4 w-4" /> Create New Course
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Students</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">1,234</div>
              <p className="text-xs text-muted-foreground">+10% from last month</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Active Courses</CardTitle>
              <BookOpen className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">12</div>
              <p className="text-xs text-muted-foreground">2 new this month</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
              <DollarSign className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">$12,345</div>
              <p className="text-xs text-muted-foreground">+15% from last month</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Avg. Completion Rate</CardTitle>
              <BarChart className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">68%</div>
              <p className="text-xs text-muted-foreground">+5% from last month</p>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="courses" className="space-y-4">
          <TabsList>
            <TabsTrigger value="courses">Courses</TabsTrigger>
            <TabsTrigger value="analytics">Analytics</TabsTrigger>
            <TabsTrigger value="students">Students</TabsTrigger>
          </TabsList>
          <TabsContent value="courses" className="space-y-4">
            <CourseList />
          </TabsContent>
          <TabsContent value="analytics" className="space-y-4">
            <CourseAnalytics />
          </TabsContent>
          <TabsContent value="students" className="space-y-4">
            <StudentList />
          </TabsContent>
        </Tabs>
      </main>

      <CreateCourseModal isOpen={isCreateCourseModalOpen} onClose={() => setIsCreateCourseModalOpen(false)} />
      <CreateContentModal isOpen={isCreateContentModalOpen} onClose={() => setIsCreateContentModalOpen(false)} />
    </div>
  )
}

