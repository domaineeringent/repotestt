import { UltraConvertingMenu } from "@/components/UltraConvertingMenu"
import { Button } from "@/components/ui/button"
import { motion } from "framer-motion"
import Image from "next/image"

export default function About() {
  return (
    <main className="bg-gray-900 text-white">
      <UltraConvertingMenu />

      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-b from-blue-900 to-gray-900">
        <div className="container mx-auto px-4">
          <motion.h1
            className="text-5xl md:text-6xl font-bold mb-8 text-center"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            Revolutionizing Content Creation
          </motion.h1>
          <motion.p
            className="text-xl mb-12 text-center max-w-3xl mx-auto"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            At PromptPacks, we're on a mission to empower creators, marketers, and businesses with AI-driven content
            solutions that save time, boost productivity, and unleash creativity.
          </motion.p>
        </div>
      </section>

      {/* Our Story */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl font-bold mb-8 text-center">Our Story</h2>
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <p className="text-lg mb-6">
                Founded in 2023, PromptPacks emerged from a simple idea: what if we could harness the power of AI to
                revolutionize content creation? Our founders, a team of AI enthusiasts and content marketing experts,
                set out to build a platform that would make high-quality, AI-generated content accessible to everyone.
              </p>
              <p className="text-lg mb-6">
                Today, PromptPacks is at the forefront of the AI content revolution, constantly innovating and pushing
                the boundaries of what's possible with AI-driven content creation.
              </p>
            </div>
            <div className="relative h-96">
              <Image
                src="/placeholder.svg"
                alt="PromptPacks Team"
                layout="fill"
                objectFit="cover"
                className="rounded-lg"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Our Values */}
      <section className="py-20 bg-gray-800">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl font-bold mb-12 text-center">Our Values</h2>
          <div className="grid md:grid-cols-3 gap-8">
            {[
              { title: "Innovation", description: "We're constantly pushing the boundaries of AI technology." },
              { title: "Quality", description: "We're committed to delivering the highest quality content." },
              { title: "User-Centric", description: "Our users' success is at the heart of everything we do." },
            ].map((value, index) => (
              <motion.div
                key={index}
                className="bg-gray-700 p-6 rounded-lg"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <h3 className="text-2xl font-semibold mb-4">{value.title}</h3>
                <p>{value.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Team */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl font-bold mb-12 text-center">Meet Our Team</h2>
          <div className="grid md:grid-cols-3 gap-8">
            {[
              { name: "Jane Doe", role: "CEO & Co-Founder" },
              { name: "John Smith", role: "CTO & Co-Founder" },
              { name: "Alice Johnson", role: "Head of AI Research" },
            ].map((member, index) => (
              <div key={index} className="text-center">
                <div className="w-48 h-48 mx-auto mb-4 rounded-full overflow-hidden">
                  <Image src="/placeholder.svg" alt={member.name} width={192} height={192} objectFit="cover" />
                </div>
                <h3 className="text-2xl font-semibold mb-2">{member.name}</h3>
                <p className="text-gray-400">{member.role}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-20 bg-blue-600">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-4xl md:text-5xl font-bold mb-8">Join the PromptPacks Revolution</h2>
          <p className="text-xl mb-8">Experience the future of content creation with our AI-powered platform.</p>
          <Button size="lg" className="bg-white text-blue-600 hover:bg-gray-100">
            Start Your Free Trial
          </Button>
        </div>
      </section>
    </main>
  )
}

