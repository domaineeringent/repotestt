import { UltraConvertingMenu } from "@/components/UltraConvertingMenu"
import { ConversionFunnel } from "@/components/ConversionFunnel"
import { IMAXFeatures } from "@/components/IMAXFeatures"
import { IMAXPricing } from "@/components/IMAXPricing"
import { Button } from "@/components/ui/button"
import { ArrowRight, Check, Star } from "lucide-react"
import Link from "next/link"
import { CourseSelection } from "@/components/CourseSelection"

export default function Home() {
  return (
    <main className="bg-gray-900 text-white">
      <UltraConvertingMenu />

      {/* Hero Section with Conversion Funnel */}
      <section className="py-20 bg-gradient-to-b from-blue-900 to-gray-900">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center justify-between">
            <div className="md:w-1/2 mb-8 md:mb-0">
              <h1 className="text-4xl md:text-5xl font-bold mb-6">Transform Your Content Creation with AI</h1>
              <p className="text-xl mb-6">
                Generate high-quality, diverse content in minutes with PromptPacks. Streamline your workflow and boost
                your productivity.
              </p>
            </div>
            <div className="md:w-1/2">
              <ConversionFunnel />
            </div>
          </div>
        </div>
      </section>

      {/* Value Proposition */}
      <section className="py-20 bg-gradient-to-b from-gray-900 to-gray-800">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl md:text-5xl font-bold mb-8 text-center">Why Choose PromptPacks?</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-gray-800 p-6 rounded-lg">
              <Star className="w-12 h-12 text-yellow-400 mb-4" />
              <h3 className="text-2xl font-semibold mb-4">AI-Powered Brilliance</h3>
              <p>Harness the power of cutting-edge AI to generate high-quality content in minutes, not hours.</p>
            </div>
            <div className="bg-gray-800 p-6 rounded-lg">
              <Check className="w-12 h-12 text-green-400 mb-4" />
              <h3 className="text-2xl font-semibold mb-4">Tailored to Your Brand</h3>
              <p>Customizable outputs ensure your content always matches your unique brand voice and style.</p>
            </div>
            <div className="bg-gray-800 p-6 rounded-lg">
              <ArrowRight className="w-12 h-12 text-blue-400 mb-4" />
              <h3 className="text-2xl font-semibold mb-4">Streamlined Workflow</h3>
              <p>Intuitive interface and rapid turnaround times revolutionize your content creation process.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Course Offerings */}
      <section className="py-20 bg-gray-100 dark:bg-gray-800">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl md:text-5xl font-bold mb-8 text-center">Enhance Your Skills with Our Courses</h2>
          <p className="text-xl mb-12 text-center max-w-3xl mx-auto">
            Whether you're just starting out or looking to master advanced techniques, we have the perfect course for
            you.
          </p>
          <CourseSelection onSelectCourse={() => {}} />
        </div>
      </section>

      <IMAXFeatures />

      {/* Social Proof */}
      <section className="py-20 bg-gray-800">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl md:text-5xl font-bold mb-12 text-center">Trusted by Industry Leaders</h2>
          <div className="grid md:grid-cols-3 gap-8">
            {[1, 2, 3].map((i) => (
              <div key={i} className="bg-gray-700 p-6 rounded-lg">
                <div className="flex items-center mb-4">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <Star key={star} className="w-5 h-5 text-yellow-400" fill="currentColor" />
                  ))}
                </div>
                <p className="mb-4">
                  "PromptPacks has revolutionized our content creation process. We're producing more high-quality
                  content faster than ever before."
                </p>
                <div className="font-semibold">John Doe, CEO of TechCorp</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <IMAXPricing />

      {/* Call to Action */}
      <section className="py-20 bg-blue-600">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-4xl md:text-5xl font-bold mb-8">Ready to Revolutionize Your Content Creation?</h2>
          <p className="text-xl mb-8">
            Join thousands of satisfied customers and start creating amazing content today.
          </p>
          <Link href="#top">
            <Button size="lg" className="bg-white text-blue-600 hover:bg-gray-100">
              Start Your Free Trial Now
            </Button>
          </Link>
        </div>
      </section>
    </main>
  )
}

