import { UltraConvertingMenu } from "@/components/UltraConvertingMenu"
import { Button } from "@/components/ui/button"
import { Check } from "lucide-react"
import Link from "next/link"

const plans = [
  {
    name: "Starter",
    price: 49,
    features: [
      "100 AI-generated content packs per month",
      "Basic prompt templates",
      "Email support",
      "API access (100 requests/day)",
    ],
    cta: "Start Free Trial",
  },
  {
    name: "Pro",
    price: 99,
    features: [
      "300 AI-generated content packs per month",
      "Advanced prompt templates",
      "Priority email and chat support",
      "API access (1000 requests/day)",
      "Custom AI model fine-tuning",
    ],
    cta: "Start Free Trial",
    highlighted: true,
  },
  {
    name: "Enterprise",
    price: "Custom",
    features: [
      "Unlimited AI-generated content packs",
      "Custom prompt templates",
      "24/7 priority support",
      "Unlimited API access",
      "Dedicated account manager",
      "On-premise deployment options",
    ],
    cta: "Contact Sales",
  },
]

export default function Pricing() {
  return (
    <div className="min-h-screen bg-gray-100 dark:bg-gray-900">
      <UltraConvertingMenu />
      <main className="container mx-auto px-4 py-16">
        <h1 className="text-4xl font-bold text-center mb-12">Choose Your Plan</h1>
        <div className="grid md:grid-cols-3 gap-8">
          {plans.map((plan) => (
            <div
              key={plan.name}
              className={`bg-white dark:bg-gray-800 rounded-lg shadow-lg overflow-hidden ${
                plan.highlighted ? "ring-2 ring-blue-500" : ""
              }`}
            >
              <div className="p-6">
                <h2 className="text-2xl font-bold mb-4">{plan.name}</h2>
                <p className="text-4xl font-bold mb-6">
                  ${typeof plan.price === "number" ? plan.price : plan.price}
                  <span className="text-lg font-normal">/month</span>
                </p>
                <ul className="mb-6 space-y-2">
                  {plan.features.map((feature) => (
                    <li key={feature} className="flex items-center">
                      <Check className="w-5 h-5 mr-2 text-green-500" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
              </div>
              <div className="p-6 bg-gray-50 dark:bg-gray-700">
                <Link href={plan.name === "Enterprise" ? "/contact" : "/free-trial"}>
                  <Button className="w-full">{plan.cta}</Button>
                </Link>
              </div>
            </div>
          ))}
        </div>
      </main>
    </div>
  )
}

