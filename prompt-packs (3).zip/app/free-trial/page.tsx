"use client"

import { useState, useEffect } from "react"
import { UltraConvertingMenu } from "@/components/UltraConvertingMenu"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useRouter, useSearchParams } from "next/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

export default function FreeTrial() {
  const searchParams = useSearchParams()
  const [email, setEmail] = useState("")
  const [name, setName] = useState("")
  const [cardNumber, setCardNumber] = useState("")
  const [expiry, setExpiry] = useState("")
  const [cvc, setCvc] = useState("")
  const [selectedCourse, setSelectedCourse] = useState<string | null>(null)
  const router = useRouter()

  useEffect(() => {
    setEmail(searchParams?.get("email") || "")
    setSelectedCourse(searchParams?.get("course") || null)
  }, [searchParams])

  const getCourseDetails = (courseId: string | null) => {
    switch (courseId) {
      case "content-basics":
        return { title: "Content Creation Basics", price: "Free" }
      case "advanced-prompts":
        return { title: "Advanced Prompt Engineering", price: 49 }
      case "content-strategy":
        return { title: "AI-Powered Content Strategy", price: 99 }
      default:
        return null
    }
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Here you would typically send the data to your backend
    // For now, we'll just redirect to the dashboard
    router.push("/dashboard")
  }

  return (
    <div className="min-h-screen bg-gray-100 dark:bg-gray-900">
      <UltraConvertingMenu />
      <main className="container mx-auto px-4 py-16">
        <div className="max-w-md mx-auto bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6">
          <h1 className="text-3xl font-bold mb-6 text-center">Start Your 7-Day Free Trial</h1>
          <form onSubmit={handleSubmit} className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Selected Course</CardTitle>
                <CardDescription>You've selected the following course:</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex justify-between items-center">
                  <span>{getCourseDetails(selectedCourse)?.title || "No course selected"}</span>
                  <Badge variant={selectedCourse === "content-basics" ? "secondary" : "default"}>
                    {selectedCourse === "content-basics" ? "Free" : `$${getCourseDetails(selectedCourse)?.price}`}
                  </Badge>
                </div>
              </CardContent>
            </Card>
            <div>
              <Label htmlFor="name">Full Name</Label>
              <Input id="name" type="text" value={name} onChange={(e) => setName(e.target.value)} required />
            </div>
            <div>
              <Label htmlFor="email">Email</Label>
              <Input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
            </div>
            {selectedCourse !== "content-basics" && (
              <>
                <div>
                  <Label htmlFor="cardNumber">Card Number</Label>
                  <Input
                    id="cardNumber"
                    type="text"
                    value={cardNumber}
                    onChange={(e) => setCardNumber(e.target.value)}
                    required
                    placeholder="1234 5678 9012 3456"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="expiry">Expiry Date</Label>
                    <Input
                      id="expiry"
                      type="text"
                      value={expiry}
                      onChange={(e) => setExpiry(e.target.value)}
                      required
                      placeholder="MM/YY"
                    />
                  </div>
                  <div>
                    <Label htmlFor="cvc">CVC</Label>
                    <Input
                      id="cvc"
                      type="text"
                      value={cvc}
                      onChange={(e) => setCvc(e.target.value)}
                      required
                      placeholder="123"
                    />
                  </div>
                </div>
              </>
            )}
            <Button type="submit" className="w-full">
              {selectedCourse === "content-basics" ? "Start Free Course" : "Start Your Free Trial"}
            </Button>
          </form>
          <p className="mt-4 text-sm text-center text-gray-500">
            {selectedCourse === "content-basics"
              ? "Enjoy your free course! No payment required."
              : "Your card will not be charged for 7 days. You can cancel anytime during your trial."}
          </p>
        </div>
      </main>
    </div>
  )
}

